
clear;clc
warning('off', 'all');




% load('BDGP_initali_random_state.mat')
% rng = initial_rng;

load('BDGP.mat')
% rng('shuffle');
rng(2024,'twister');
% initial_rng = rng;
% save('BDGP_initali_random_state.mat','initial_rng');


data = fea;  % data is n x d
label = gnd; % label is n x 1

%Normalize data
data = data';
data = data./repmat(sqrt(sum(data.^2)),[size(data,1) 1]);
data =data';

%-------PCA reudce dimensionality to keep 95% energy
options=[];
options.PCARatio=0.95;
[eigvector, ~] = PCA1(data, options);
data = data*eigvector;

Train_data =data'; %Train_data is a (d x n) matrix.


n_samples = size(Train_data,2);
nClass = length(unique(label));
alpha = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4];
beta = [1e-4,1e-3,1e-2,1e-1,1e0,1e1,1e2,1e3,1e4];
n_anchors = ceil(0.15*n_samples);





ACC = zeros(length(alpha),length(beta));
NMI = zeros(length(alpha),length(beta));
Purity = zeros(length(alpha),length(beta));
Precision = zeros(length(alpha),length(beta));
F1score = zeros(length(alpha),length(beta));
Sil = zeros(length(alpha),length(beta));



% initalize Z, B, and G
Z = VDA(Train_data', n_anchors);
D1  = L2_distance_1(Z',Z');
[distZ, idx] = sort(D1,2);
S = zeros(n_anchors);
neigh_num = 5;
for ii = 1:n_anchors
    di = distZ(ii,2:neigh_num+2);
    id = idx(ii,2:neigh_num+2);
    S(ii,id) = (di(neigh_num+1)-di)/(neigh_num*di(neigh_num+1)-sum(di(1:neigh_num))+eps);
end
S = (S+S')/2;
D = sqrt(diag(sum(S)));
newS = D*S*D;
[B, Egma] = eig1(newS, nClass, 1);
Egma = diag(sqrt(Egma));
Egma = real(Egma);
B = B *Egma;

%%% init G
para = [];
para.k = neigh_num;
para.nc = nClass;

G = Laplacian_GK(Z', para,S);
opts = statset('MaxIter', 20, 'Display', 'off');
while 1
    StartInd = kmeans(Z, nClass, ...
        'Start', 'plus', ...        % k-means++
        'Replicates', 3, ...       % 多次初始化
        'Options', opts);
    temp=length(unique(StartInd));
    if temp==nClass
        G0 = LabelFormat(StartInd);
        break;
    end
end


G = SRvsKM(G, G0);


%% 遍历 α, β 组合
for i=1:length(alpha)
    for j =1:length(beta)
        predict = NBGC12CD(Train_data,Z',G,B,nClass,alpha(i),beta(j));
        result = ClusteringMeasure(gnd, predict);
        ACC(i,j)=result(1);
        NMI(i,j)=result(2);
        Purity(i,j)=result(3);
        Precision(i,j)=result(4);
        F1score(i,j)=result(5);
    end
end


