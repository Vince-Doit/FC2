% Spectral rotation: min_{G=Ind,Q'*Q=I} || G*Q - F ||^2
function Gsr = SRvsKM(F, G)
% F: n*c matrix, the c smallest eigenvectors of (normalized) Laplacian matrix
% G: n*c initial cluster indicator matrix
% Gkm: achieved cluster indicator matrix via K-means
% obj_km: objective value of K-means method
% Gsr: achieved cluster indicator matrix via spectral rotation
% obj_sr: objective value of spectral rotation method
% success: if some clusters are null, success=0, if all clusters are not null, success=1



[n,c] = size(F);

izero = find(sum(abs(F),2) <= 10^-10);
F(izero,:) = 1;
F = diag(diag(F*F').^(-1/2)) * F;


Gsr = G;
ITER = 30;
obj_sr = zeros(ITER,1);
for iter = 1:ITER
    
    % SR discrete
    [U, d, V] = svd(Gsr'*F);
    Q = U*V';
    Gsr = calculateR(F, Q, 0, 1);
    obj_sr(iter) = trace((F-Gsr*Q)'*(F-Gsr*Q));
    
   % succ = sum([Gkm,Gsr]);     
end




% if find(succ==0)
%     success = 0; 
% end; 


function G1 = calculateR(F, H, a, BQ)

[n,class_num] = size(F);

T = zeros(n,class_num);
for i = 1:class_num
    te = F - ones(n,1)*H(i,:);
    aa = sum(te.*te,2);
    T(:,i) = aa;
end;
T = T - a*2*BQ;
[temp idx] = min(T,[],2);
G1 = zeros(n,class_num);
for i = 1:n
    G1(i,idx(i)) = 1;
end;




    