function F = Laplacian_GK(X, para,S)

if isfield(para,'k')
    k = para.k;
else
    k = 5;
end

if isfield(para,'nc')
    c = para.nc;
else
    error('para.nc must be specified');
end

[nFea, nSmp] = size(X);

%% -------- Step 1: kNN search (no full distance matrix)
% transpose X to n x d for knnsearch
[idx, ~] = knnsearch(X', X', 'K', k+1);  % first neighbor is itself

%% -------- Step 2: construct sparse kNN graph
W = spalloc(nSmp, nSmp, k*nSmp);

for i = 1:nSmp
    W(i, idx(i,2:end)) = 1;
end

W = (W+W')/2;% symmetric kNN graph
W = S;
%% -------- Step 3: normalized Laplacian
deg = sum(W,2);
Dd = deg + 1e-12;
Dn = spdiags(1./sqrt(Dd), 0, nSmp, nSmp);

An = Dn * W * Dn;
Ln = speye(nSmp) - An;

%% -------- Step 4: partial eigen-decomposition
opts.isreal = 1;
opts.issym  = 1;

% compute smallest c+1 eigenvectors
[F_all, ~] = eigs(Ln, c+1, 'smallestreal', opts);

% discard the first trivial eigenvector
F = F_all(:, 2:c+1);

end
