function F = Laplacian_GK_fast(X, para)
% each column is a data

if isfield(para, 'k')
    k = para.k;
else
    k = 20;
end;
if isfield(para, 'sigma')
    sigma = para.sigma;
else
    sigma = 1;
end;

    [nFea, nSmp] = size(X);
    D = L2_distance(X,X);

    W = spalloc(nSmp, nSmp, 20 * nSmp);  % 初始化稀疏矩阵
    tempW = sparse(nSmp, nSmp);  % 创建临时稀疏矩阵

    [dumb, idx] = sort(D, 2);  % 排序

    parfor i = 1:nSmp
        % 为每行创建一个临时的局部矩阵，只修改特定的列
        tempRow = sparse(1, nSmp);  % 为每一行创建一个临时稀疏行
        tempRow(idx(i, 2:k+1)) = 1;  % 更新临时行
        tempW(i, :) = tempRow;  % 将该行赋值给 tempW
    end


    W = (tempW+tempW')/2;
    
    D = diag(sum(W,2));
    % L = D - W;
    % A = W;
    
    Dd = diag(D)+10^-12;
    Dn=diag(sqrt(1./Dd)); Dn = sparse(Dn);
    An = Dn*W*Dn; An = (An+An')/2;
    Ln=speye(size(W,1)) - An;

    % Ln=full(Ln);

    M = (Ln+Ln')/2;
    [v,d] = eigs(M,para.nc+1);
    [d, idx] = sort(diag(d));

    F = v(:, idx(2:para.nc+1));
    
    
    
    