function F = NBGC12CD(X,Z,G,B,c,beta,lambda)


% input:
% X is the  data matrix with size (d x n)
% Z is the anchor points
% beta is the hyper-parameter 
% c is the numnber of classes
% output:
% obj contains the objective function valuess 
% F is the indicator matrix with size (n x c)
% G is the indicator matrix with size (m x c)

n_samples  = size(X,2);   %  d x n
D2  = L2_distance_1(X,Z);

%%% init F
F = zeros(n_samples,c);
[~,ind] = min(D2,[],2);
for i=1:n_samples
    F(i,:)=G(ind(i),:);
end


maxIter = 50;
obj =zeros(1,maxIter);
I1 = ones(1,n_samples);

for it = 1:maxIter



    % update Q
    tempQ = B'*G;
    [U, ~, V] = svd(tempQ);
    Q = U*V';
    Q = real(Q);


    % update G
    tempG = B*Q-D2'*F/beta; 
    G = binarizeM(tempG, 'max');

   
   % update F
   M = D2*G;
   F = NBGC12_F_CD(F, M, 1/lambda);
   % F = NBGC12_F_AB(M);

    % objective function
    obF = I1*F;
    obG = G-B*Q;
    obj(it) =  trace(F'*D2*G) + 0.5*beta*trace(obG*obG') + lambda*trace(F'*I1'*obF);
    if it > 1 && abs(obj(it - 1) - obj(it)) / abs(obj(it - 1)) < 1e-4
        break
    end

end


[~,F] = max(F, [], 2);
