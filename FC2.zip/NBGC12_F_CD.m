% function [Y,Obj] = NBGC12_F_CD(Y, M, lambda)
function Y = NBGC12_F_CD(Y, M, lambda)

% min_{Y\in ind}  Tr(Y'11'Y) + lambda *Tr(Y'*M)
% OUTPUT:
% F: generated label matrix (n by c)


[n,c] = size(Y);
maxiter = 20;
% Obj = zeros(1,maxiter);
for iter=1:maxiter
    class_count = sum(Y);
    % temp_obj = zeros(1,n);
    for i=1:n
        index =  nonzeros(find(Y(i,:))); % 找到Y的第i行中1的位置，也就是第i个样本的簇号
        class_count(index) = class_count(index)-1;  % 直接将第i个样本所属簇的元素值-1
        % a = (2*class_count + lambda*M(i,:))./2;
        a = 2*class_count + lambda*M(i,:);
        [~, index] = min(a);
        Y(i,:) = zeros(1,c);
        Y(i,index) = 1;
        class_count(index) = class_count(index)+1;
        % 测试每行更新后目标函数是否收敛
        % temp_obj(i)= trace(Y'*ones(n)*Y)- lambda* trace(Y'*M);
    end
    % 测试每轮更新后目标函数是否收敛
    % Obj(iter)= trace(Y'*ones(n)*Y)+ lambda* trace(Y'*M);

    % if (iter>1 && abs(Obj(iter)-Obj(iter-1))/abs(Obj(iter)) < 10^-5)
    % if (iter>1 && abs(Obj(iter)-Obj(iter-1)) < 10^-4)
    %     Obj = Obj(1:iter);
    %     % plot(obj);
    %     break;
    % end
end
